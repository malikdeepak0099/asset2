const $ = (s) => document.querySelector(s);
async function show() {
  const { state, key } = await chrome.storage.local.get(['state', 'key']);
  $('#st').textContent = (state && state.text) || (key ? 'Paired — checking…' : 'Not paired yet');
  if (key) $('#k').placeholder = key.slice(0, 8) + '… (saved)';
}
$('#save').onclick = async () => {
  const key = $('#k').value.trim();
  if (!/^kgx_[\w-]{20,}$/.test(key)) { $('#st').textContent = '⚠️ Paste the key from keygroup.ge → My profile'; return; }
  const r = await fetch('https://keygroup.ge/api/ext/ping', { headers: { 'X-KG-Ext': key } }).then((x) => x.json()).catch(() => ({ ok: false, error: 'keygroup.ge did not answer' }));
  if (!r.ok) { $('#st').textContent = '⚠️ ' + (r.error || 'Key not valid'); return; }
  await chrome.storage.local.set({ key });
  $('#k').value = '';
  $('#st').textContent = '✅ ' + r.name + ' — connected' + (r.waiting ? ' · ' + r.waiting + ' waiting' : '');
  chrome.runtime.sendMessage('check');
};
$('#now').onclick = () => { $('#st').textContent = '⏳ Checking…'; chrome.runtime.sendMessage('check', () => show()); };
show();
