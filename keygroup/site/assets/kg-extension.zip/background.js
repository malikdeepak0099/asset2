// KEY GROUP Publisher — runs in the agent's own Chrome. Every minute it asks keygroup.ge for listings the agent approved
// for MyHome.ge / SS.ge, opens the add-listing page in a background tab, loads the KEY GROUP publisher script there
// (it fills the form and presses Publish) and waits for the result. The agent's MyHome / SS login never leaves the browser.
const API = 'https://keygroup.ge';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let busy = false;

async function getKey() { return (await chrome.storage.local.get('key')).key || ''; }
async function setState(patch) { const s = (await chrome.storage.local.get('state')).state || {}; await chrome.storage.local.set({ state: Object.assign(s, patch, { at: Date.now() }) }); }
async function api(path, key) {
  const r = await fetch(API + path, { headers: { 'X-KG-Ext': key }, cache: 'no-store' });
  return r.json().catch(() => ({ ok: false, error: 'HTTP ' + r.status }));
}
function badge(text, color) { chrome.action.setBadgeText({ text }); if (color) chrome.action.setBadgeBackgroundColor({ color }); }

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create('poll', { periodInMinutes: 1 }));
chrome.runtime.onStartup.addListener(() => chrome.alarms.create('poll', { periodInMinutes: 1 }));
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'poll') tick(); });
chrome.runtime.onMessage.addListener((msg, _s, reply) => { if (msg === 'check') { tick().then(() => reply(true)); return true; } });

async function waitLoaded(tabId, ms) {
  for (let t = 0; t < ms; t += 500) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) return false;
    if (tab.status === 'complete') return true;
    await sleep(500);
  }
  return true;
}

async function runSite(job, site, key) {
  const name = site === 'myhome' ? 'MyHome' : 'SS';
  await setState({ text: '⏳ #' + job.listing_id + ' → ' + name + '…' });
  const tab = await chrome.tabs.create({ url: job.urls[site], active: false });
  await waitLoaded(tab.id, 60000);
  await sleep(3000);
  await chrome.scripting.executeScript({
    target: { tabId: tab.id }, world: 'MAIN',
    func: (src) => { const s = document.createElement('script'); s.src = src; document.body.appendChild(s); },
    args: [API + '/assets/kg-publish.js?v=' + Date.now()]
  });
  let focused = false;
  for (let t = 0; t < 15 * 60; t += 5) {          // up to 15 minutes (an SMS code may be needed)
    await sleep(5000);
    chrome.runtime.getPlatformInfo(() => {});      // keeps the background worker awake while it waits
    const j = (await api('/api/ext/job/' + job.id, key)).job;
    const st = j && j.site_status && j.site_status[site];
    if (!st) continue;
    if (st.state === 'done') { await sleep(4000); chrome.tabs.remove(tab.id).catch(() => {}); return 'done'; }
    if (st.state === 'failed') { return 'failed'; }  // the tab stays open so the agent can see what MyHome / SS said
    if (st.state === 'needs_otp' && !focused) {
      focused = true;
      chrome.tabs.update(tab.id, { active: true }).catch(() => {});
      chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
      await setState({ text: '🔐 ' + name + ': enter the SMS code in the open window and press Publish' });
    }
  }
  return 'timeout';
}

async function tick() {
  if (busy) return;
  const key = await getKey();
  if (!key) { badge('!', '#E2725B'); await setState({ text: 'Not paired — open keygroup.ge → My profile → KEY GROUP extension' }); return; }
  busy = true;
  try {
    const r = await api('/api/ext/next', key);
    if (!r.ok) { badge('!', '#E2725B'); await setState({ text: r.error || 'keygroup.ge did not answer' }); return; }
    if (!r.job) { badge('', null); await setState({ text: '✅ Connected — waiting for listings', idle: true }); return; }
    badge('…', '#D4A853');
    const res = {};
    for (const site of r.job.sites) res[site] = await runSite(r.job, site, key);
    await setState({ text: '#' + r.job.listing_id + ': ' + Object.entries(res).map(([k, v]) => (k === 'myhome' ? 'MyHome ' : 'SS ') + (v === 'done' ? '✅' : '⚠️ ' + v)).join(' · ') });
    badge('', null);
  } catch (e) {
    await setState({ text: 'Error: ' + e.message });
  } finally {
    busy = false;
  }
}
