// KEY GROUP Publisher — runs in the agent's own Chrome. Every minute it asks keygroup.ge for listings the agent approved
// for MyHome.ge / SS.ge, opens the add-listing page in a background tab, loads the KEY GROUP publisher script there
// (it fills the form and presses Publish) and waits for the result. The agent's MyHome / SS login never leaves the browser.
const API = 'https://keygroup.ge';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let busy = false;

async function getKey() { return (await chrome.storage.local.get('key')).key || ''; }
async function setState(patch) { const s = (await chrome.storage.local.get('state')).state || {}; await chrome.storage.local.set({ state: Object.assign(s, patch, { at: Date.now() }) }); }
async function api(path, key) {
  const r = await fetch(API + path, { headers: { 'X-KG-Ext': key }, cache: 'no-store' });
  return r.json().catch(() => ({ ok: false, error: 'HTTP ' + r.status }));
}
function badge(text, color) { chrome.action.setBadgeText({ text }); if (color) chrome.action.setBadgeBackgroundColor({ color }); }

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create('poll', { periodInMinutes: 0.5 }));
chrome.runtime.onStartup.addListener(() => chrome.alarms.create('poll', { periodInMinutes: 0.5 }));
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'poll') tick(); });
chrome.runtime.onMessage.addListener((msg, _s, reply) => { if (msg === 'check') { tick().then(() => reply(true)); return true; } });

async function waitLoaded(tabId, ms) {
  for (let t = 0; t < ms; t += 500) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) return false;
    if (tab.status === 'complete') return true;
    await sleep(500);
  }
  return true;
}

async function runSite(job, site, key) {
  const name = site === 'myhome' ? 'MyHome' : 'SS';
  await setState({ text: '⏳ #' + job.listing_id + ' → ' + name + '…' });
  // the tab must be in front: Chrome slows background tabs down to about one step per minute after 5 minutes
  const tab = await chrome.tabs.create({ url: job.urls[site], active: true });
  chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  await waitLoaded(tab.id, 60000);
  await sleep(3000);
  await chrome.scripting.executeScript({
    target: { tabId: tab.id }, world: 'MAIN',
    func: (src) => { const s = document.createElement('script'); s.src = src; document.body.appendChild(s); },
    args: [API + '/assets/kg-publish.js?v=' + Date.now()]
  });
  const code = ((job.urls[site] || '').match(/kgauto=([A-Z0-9]+)/i) || [])[1] || job.code || '';
  const status = (state) => fetch(API + '/api/publish/' + code + '/status', { method: 'POST', body: JSON.stringify({ site, state, message: state === 'paid' ? 'paid by the agent' : 'payment page' }) }).catch(() => {});
  // automatic part: at most 5 minutes. When the site needs the agent (payment / SMS code) we leave that tab open for them and
  // go straight on to the other site — a watcher keeps following this tab in the background.
  for (let t = 0; t < 5 * 60; t += 3) {
    await sleep(3000);
    chrome.runtime.getPlatformInfo(() => {});      // keeps the background worker awake while it waits
    const cur = await chrome.tabs.get(tab.id).catch(() => null);
    if (!cur) return 'closed';
    const url = cur.url || '';
    if (site === 'myhome' && /checkout/i.test(url)) {   // MyHome free limit used: the agent pays on MyHome's own page — we never press pay
      await status('needs_payment'); watchAgentStep(job, site, key, tab, status, 'pay');
      return 'waiting for the agent to pay';
    }
    const j = (await api('/api/ext/job/' + job.id, key)).job;
    const st = j && j.site_status && j.site_status[site];
    if (!st) continue;
    if (st.state === 'done') { await sleep(3000); chrome.tabs.remove(tab.id).catch(() => {}); return 'done'; }
    if (st.state === 'failed') return 'failed';      // the tab stays open so the agent can see what MyHome / SS said
    if (st.state === 'needs_payment') { watchAgentStep(job, site, key, tab, status, 'pay'); return 'waiting for the agent to pay'; }
    if (st.state === 'needs_otp') { watchAgentStep(job, site, key, tab, status, 'otp'); return 'waiting for the SMS code'; }
  }
  return 'no answer in 5 min';
}

const waiting = new Map();   // tabId → what the agent still has to do there
function watchAgentStep(job, site, key, tab, status, what) {
  const name = site === 'myhome' ? 'MyHome' : 'SS';
  waiting.set(tab.id, { name, what, listing: job.listing_id });
  (async () => {
    let paidSent = false;
    for (let t = 0; t < 20 * 60; t += 5) {          // the agent has up to 20 minutes; nothing else waits for this
      await sleep(5000);
      chrome.runtime.getPlatformInfo(() => {});
      const cur = await chrome.tabs.get(tab.id).catch(() => null);
      if (!cur) break;
      const url = cur.url || '';
      if (what === 'pay' && !paidSent && !/checkout/i.test(url) && /success/i.test(url)) { paidSent = true; await status('paid'); }
      const j = (await api('/api/ext/job/' + job.id, key)).job;
      const st = j && j.site_status && j.site_status[site];
      if (st && st.state === 'done' && !/checkout/i.test(url)) { await sleep(3000); chrome.tabs.remove(tab.id).catch(() => {}); break; }
      if (st && st.state === 'failed') break;
    }
    waiting.delete(tab.id);
  })();
}

async function tick() {
  if (busy) return;
  const key = await getKey();
  if (!key) { badge('!', '#E2725B'); await setState({ text: 'Not paired — open keygroup.ge → My profile → KEY GROUP extension' }); return; }
  busy = true;
  try {
    const r = await api('/api/ext/next', key);
    if (!r.ok) { badge('!', '#E2725B'); await setState({ text: r.error || 'keygroup.ge did not answer' }); return; }
    if (!r.job) { badge('', null); await setState({ text: '✅ Connected — waiting for listings', idle: true }); return; }
    badge('…', '#D4A853');
    const res = {};
    for (const site of r.job.sites) res[site] = await runSite(r.job, site, key);
    // bring back the tabs where the agent has something to do (payment / SMS code)
    const todo = [...waiting.entries()].filter(([, w]) => w.listing === r.job.listing_id);
    if (todo.length) {
      const tab = await chrome.tabs.get(todo[0][0]).catch(() => null);
      if (tab) { chrome.tabs.update(tab.id, { active: true }).catch(() => {}); chrome.windows.update(tab.windowId, { focused: true }).catch(() => {}); }
    }
    await setState({ text: '#' + r.job.listing_id + ': ' + Object.entries(res).map(([k, v]) => (k === 'myhome' ? 'MyHome ' : 'SS ') + (/^done/.test(v) ? '✅' : /^waiting/.test(v) ? '💳/🔐 ' + v : '⚠️ ' + v)).join(' · ') });
    badge('', null);
  } catch (e) {
    await setState({ text: 'Error: ' + e.message });
  } finally {
    busy = false;
  }
}
